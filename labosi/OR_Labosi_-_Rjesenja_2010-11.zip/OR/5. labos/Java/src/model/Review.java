package model;

public class Review {

	private Osoba recenzent;
	private String recenzija;

	public Osoba getRecenzent() {
		return recenzent;
	}

	public void setRecenzent(Osoba recenzent) {
		this.recenzent = recenzent;
	}

	public String getRecenzija() {
		return recenzija;
	}

	public void setRecenzija(String recenzija) {
		this.recenzija = recenzija;
	}

}
