﻿Ovo je moj labos 2014./2015.

Dobio sam 18/24, 1 bod izgubio na 1. labosu i 1 na 5. labosu.

4 boda fale jer nisam radio 6. labos.

Ovo je primjer LOŠIJEG koda, sve je napravljeno tek toliko da radi.

Koristite ovaj labos da shvatite kako stvari rade, ima nekih komentara, nemojte ni slučajno prepisivati postoji provjera plagijata. Ne garantiram da je sve točno i da sve radi kako treba i da uopće radi.

Nadam se da će vam moj labos barem malo pomoći :)