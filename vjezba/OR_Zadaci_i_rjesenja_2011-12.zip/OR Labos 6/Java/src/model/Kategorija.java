package model;

public enum Kategorija {
	prijatelj,
	kolega,
	obitelj,
	bez_kategorije
}
