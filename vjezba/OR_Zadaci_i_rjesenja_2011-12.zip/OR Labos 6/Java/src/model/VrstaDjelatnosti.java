package model;

public enum VrstaDjelatnosti {
	none,
	ostalo,
	transport,
	kultura,
	sport,
	trgovina,
	opce,
	financije,
	usluge,
	turizam
}
