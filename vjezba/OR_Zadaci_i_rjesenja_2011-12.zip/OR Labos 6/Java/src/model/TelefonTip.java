package model;

public enum TelefonTip {
	mobilni,
	fiksni,
	telefaks
}
